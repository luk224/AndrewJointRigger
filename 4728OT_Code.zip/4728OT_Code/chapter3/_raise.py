"""Import to cause an exception, to test our hooks."""

__author__ = 'rob.galanakis@gmail.com'

raise NotImplementedError