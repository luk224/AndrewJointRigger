"""Same as v5."""

# noinspection PyUnresolvedReferences
from hierarchyconvertermaya_5 import *
