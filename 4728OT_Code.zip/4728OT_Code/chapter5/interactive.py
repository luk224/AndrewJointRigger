
def interactive():
    """
    Code for all the interactive prompts throughout the chapter.
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod()
