print 'Hello, you are in', __name__
if __name__ == '__main__':
    print 'Running main'
print 'Finishing'
